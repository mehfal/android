package com.mehfal.testapp;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.mehfal.testapp.Adapter.MyProductAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity2 extends AppCompatActivity implements PurchasesUpdatedListener {
    private BillingClient billingClient;

    Button loadProducts;
    RecyclerView recylcer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        setupBillingClient();

        Purchase.PurchasesResult purchasesResult = billingClient.queryPurchases(BillingClient.SkuType.INAPP);
        if (purchasesResult != null) {
            List<Purchase> lst = purchasesResult.getPurchasesList();
            if (lst != null)
                for (Purchase purchase : lst) {
                Toast.makeText(this, purchase.getSku(), Toast.LENGTH_SHORT).show();
            }//details of each item


        }

        loadProducts = (Button) findViewById(R.id.btn_load_product);
        recylcer = (RecyclerView) findViewById(R.id.recycler_product);

        recylcer.setHasFixedSize(true);
        recylcer.setLayoutManager(new LinearLayoutManager(this));

        final List<String> skuList = new ArrayList<>();
        skuList.add("test_app_id");
        skuList.add("test_app_2");

        loadProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "button click", Toast.LENGTH_SHORT).show();
                if (billingClient.isReady())
                {
                    SkuDetailsParams params = SkuDetailsParams.newBuilder()
                            .setSkusList(Arrays.asList("test_app_id","test_app_2")).setType(BillingClient.SkuType.INAPP) // for managed products, otherwise SUBS
                            .build();

                    billingClient.querySkuDetailsAsync(params, new SkuDetailsResponseListener() {
                        @Override
                        public void onSkuDetailsResponse(int responseCode, List<SkuDetails> skuDetailsList) {
                            if (responseCode == BillingClient.BillingResponse.OK && skuDetailsList != null)
                                //for (SkuDetails skuDetails : skuDetailsList) {}//details of each item
                                loadProductToRecyclerView(skuDetailsList);
                            else
                                Toast.makeText(MainActivity2.this, "Cannot query products", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                    Toast.makeText(MainActivity2.this, "billing client is not ready", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void loadProductToRecyclerView(List<SkuDetails> skuDetailsList) {
        MyProductAdapter adapter = new MyProductAdapter(this, skuDetailsList, billingClient);
        recylcer.setAdapter(adapter);
    }

    private void setupBillingClient() {
        billingClient = BillingClient.newBuilder(this).setListener(this).build();
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(int responseCode) {
                if (responseCode == BillingClient.BillingResponse.OK)
                {
                    Toast.makeText(MainActivity2.this, "Success in connecting to billing", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(MainActivity2.this, "failed to connect to billing " + responseCode, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onBillingServiceDisconnected() {
                Toast.makeText(MainActivity2.this, "you are disconnected from the billing service", Toast.LENGTH_SHORT).show();

            }
        });
    }


    @Override
    public void onPurchasesUpdated(int responseCode, @Nullable List<Purchase> purchases) {
        if (responseCode == BillingClient.BillingResponse.OK && purchases != null) {
            Toast.makeText(this, "purchased done ", Toast.LENGTH_SHORT).show();
            for (Purchase purchase : purchases) {

                Toast.makeText(this, "" + purchase.getPurchaseToken(), Toast.LENGTH_SHORT).show();

            }
        }
        else if (responseCode == BillingClient.BillingResponse.USER_CANCELED)
            Toast.makeText(this, "user canceled" , Toast.LENGTH_SHORT).show();



    }
}
