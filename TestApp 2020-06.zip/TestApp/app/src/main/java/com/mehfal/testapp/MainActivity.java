package com.mehfal.testapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchaseHistoryRecord;
import com.android.billingclient.api.PurchaseHistoryResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements PurchasesUpdatedListener {

    private BillingClient billingClient;
    private List skuList = new ArrayList();

    private String sku = "mycoins";

    private Button buttonBuyProduct;

    private SkuDetails mSkuDetails;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_app_billing);

        buttonBuyProduct = (Button) findViewById(R.id.btnBuy);
        buttonBuyProduct.setEnabled(false);

        skuList.add(sku);
        //skuList.size();

        Boolean b = getBoolFromPref(this,"myPref", sku);
//        if (b)
//        {
//            Toast.makeText(this, "you are a premium user", Toast.LENGTH_SHORT).show();
//            buttonBuyProduct.setVisibility(View.INVISIBLE);
//        }
//        else
//        {
            setupBillingClient();
//        }
    }

    private void setupBillingClient() {
        billingClient = BillingClient.newBuilder(this).enablePendingPurchases().setListener(this).build();
        billingClient.startConnection(new BillingClientStateListener(){
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {

                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    // The BillingClient is setup successfully
                    loadAllSKUs();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.
            }
        });
    }

    private void loadAllSKUs() {
        if (billingClient.isReady())
        {
            //Toast.makeText(MainActivity.this, "billingclient ready", Toast.LENGTH_SHORT).show();
            SkuDetailsParams params = SkuDetailsParams.newBuilder()
                    .setSkusList(skuList)
                    .setType(BillingClient.SkuType.INAPP)
                    .build();

            billingClient.querySkuDetailsAsync(params, new SkuDetailsResponseListener() {
                @Override
                public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> skuDetailsList) {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK
                            && !skuDetailsList.isEmpty())
                    {
                        for (Object skuDetailsObject : skuDetailsList) {
                            final SkuDetails skuDetails = (SkuDetails) skuDetailsObject;
                            //Toast.makeText(MainActivity.this, skuDetails.getSku() + " " + sku, Toast.LENGTH_SHORT).show();

                            if (skuDetails.getSku().equals(sku)) {
                                //Toast.makeText(MainActivity.this, "this is the sku", Toast.LENGTH_SHORT).show();
                                Purchase.PurchasesResult result =  billingClient.queryPurchases(BillingClient.SkuType.INAPP);
                                List<Purchase> purchases = result.getPurchasesList();
                                boolean isOwned = false;

                                for (Purchase purchase : purchases){
                                    String thisSKU = purchase.getSku();
                                    if (thisSKU.equals(sku)){
                                        isOwned = true;
                                        Toast.makeText(MainActivity.this, "you are a premium user", Toast.LENGTH_SHORT).show();
                                        buttonBuyProduct.setVisibility(View.INVISIBLE);
                                        break;
                                        //item already owned
                                    }
                                }

                                if (!isOwned)
                                {
                                    mSkuDetails = skuDetails;
                                    buttonBuyProduct.setEnabled(true);

                                    buttonBuyProduct.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            BillingFlowParams billingFlowParams = BillingFlowParams
                                                    .newBuilder()
                                                    .setSkuDetails(skuDetails)
                                                    .build();
                                            billingClient.launchBillingFlow(MainActivity.this, billingFlowParams);

                                        }
                                    });
                                }


//                                billingClient.queryPurchaseHistoryAsync(BillingClient.SkuType.INAPP, new PurchaseHistoryResponseListener() {
//                                    @Override
//                                    public void onPurchaseHistoryResponse(BillingResult billingResult, List<PurchaseHistoryRecord> purchaseHistoryRecordList) {
//                                        //Toast.makeText(MainActivity.this, "history response:" + billingResult.getResponseCode(), Toast.LENGTH_SHORT).show();
//                                        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchaseHistoryRecordList != null)
//                                        {
//                                            boolean isOwned = false;
//                                            for (PurchaseHistoryRecord purchaseHistoryRecord : purchaseHistoryRecordList) {
//                                                String mySKU = purchaseHistoryRecord.getSku();
//                                                //Toast.makeText(MainActivity.this, "history sku=" + mySKU, Toast.LENGTH_SHORT).show();
//
//                                                if (mySKU.equals(sku))
//                                                {
//                                                    isOwned = true;
//                                                    //Toast.makeText(MainActivity.this, "you are a premium user", Toast.LENGTH_SHORT).show();
//                                                    buttonBuyProduct.setVisibility(View.INVISIBLE);
//                                                    break;
//                                                    //item already owned
//                                                }
//                                            }
//                                            if (!isOwned)
//                                            {
//                                                mSkuDetails = skuDetails;
//                                                buttonBuyProduct.setEnabled(true);
//
//                                                buttonBuyProduct.setOnClickListener(new View.OnClickListener() {
//                                                    @Override
//                                                    public void onClick(View v) {
//                                                        BillingFlowParams billingFlowParams = BillingFlowParams
//                                                                .newBuilder()
//                                                                .setSkuDetails(skuDetails)
//                                                                .build();
//                                                        billingClient.launchBillingFlow(MainActivity.this, billingFlowParams);
//
//                                                    }
//                                                });
//                                            }
//                                        }
//
//                                    }
//                                });
                            }
                        }
                    }
                }
            });
        }
        else
            Toast.makeText(MainActivity.this, "billingclient not ready", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onPurchasesUpdated(BillingResult billingResult, @Nullable List<Purchase> purchases) {
        int responseCode = billingResult.getResponseCode();
        if (responseCode == BillingClient.BillingResponseCode.OK
                && purchases != null) {
            for (Purchase purchase : purchases) {
                handlePurchase(purchase);
            }
        }
        else
        if (responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            // Handle an error caused by a user cancelling the purchase flow.
            //Log.d(TAG, "User Canceled" + responseCode);
        }
        else if (responseCode == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            ///mSharedPreferences.edit().putBoolean(getResources().getString(R.string.pref_remove_ads_key), true).commit();
            ///setAdFree(true);
            setBoolInPref(this,"myPref",sku, true );
        }
        else {
            //Log.d(TAG, "Other code" + responseCode);
            // Handle any other error codes.
        }

    }



    private void handlePurchase(Purchase purchase) {
        //Purchase.PurchasesResult result = billingClient.queryPurchases(BillingClient.SkuType.INAPP);

        if (purchase.getSku().equals(sku) && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
            if (!purchase.isAcknowledged())
            {
                AcknowledgePurchaseParams acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
                billingClient.acknowledgePurchase(acknowledgePurchaseParams, new AcknowledgePurchaseResponseListener(){

                    @Override
                    public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
                        if(billingResult.getResponseCode()== BillingClient.BillingResponseCode.OK){
                            Toast.makeText(MainActivity.this, "Purchase Acknowledged", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
            ///mSharedPreferences.edit().putBoolean(getResources().getString(R.string.pref_remove_ads_key), true).commit();
            ///setAdFree(true);
            setBoolInPref(this,"myPref",sku, true );
            Toast.makeText(this, "Purchase done. you are now a premium member.", Toast.LENGTH_SHORT).show();
        }
    }

    private Boolean getBoolFromPref(Context context, String prefName, String constantName) {
        SharedPreferences pref = context.getSharedPreferences(prefName, 0); // 0 - for private mode

        return pref.getBoolean(constantName, false);

    }

    private void setBoolInPref(Context context,String prefName, String constantName, Boolean val) {
        SharedPreferences pref = context.getSharedPreferences(prefName, 0); // 0 - for private mode

        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean(constantName, val);
        editor.commit();
    }




}
