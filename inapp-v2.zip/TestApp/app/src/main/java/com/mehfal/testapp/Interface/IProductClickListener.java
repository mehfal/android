package com.mehfal.testapp.Interface;

import android.view.View;

public interface IProductClickListener {

    void onProductClickListener(View view, int position);
}
