package com.mehfal.testapp.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.SkuDetails;
import com.mehfal.testapp.Interface.IProductClickListener;
import com.mehfal.testapp.MainActivity2;
import com.mehfal.testapp.R;

import java.util.List;

public class MyProductAdapter extends RecyclerView.Adapter<MyProductAdapter.MyViewHolder>{

    MainActivity2 mainActivity2;
    List<SkuDetails> skuDetailsList;
    BillingClient billingClient;

    public MyProductAdapter(MainActivity2 mainActivity2, List<SkuDetails> skuDetailsList, BillingClient billingClient) {
        this.mainActivity2 = mainActivity2;
        this.skuDetailsList = skuDetailsList;
        this.billingClient = billingClient;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(mainActivity2.getBaseContext())
                .inflate(R.layout.layout_product_item, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        SkuDetails detail = skuDetailsList.get(i);
        myViewHolder.text_product.setText(detail.getTitle() + ":" + detail.getSku() + ":" + detail.getPrice()+ ":" + detail.getType());

        //product click

        myViewHolder.setiProductClickListener(new IProductClickListener() {
            @Override
            public void onProductClickListener(View view, int position) {
                //launch billing flow
                BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                        .setSkuDetails(skuDetailsList.get(position)).build();

                billingClient.launchBillingFlow(mainActivity2, billingFlowParams);
            }
        });

    }

    @Override
    public int getItemCount() {
        return skuDetailsList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView text_product;

        IProductClickListener iProductClickListener;

        public void setiProductClickListener(IProductClickListener iProductClickListener) {
            this.iProductClickListener = iProductClickListener;
        }

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            text_product = (TextView) itemView.findViewById(R.id.txt_product_name);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            iProductClickListener.onProductClickListener(v, getAdapterPosition());
        }
    }
}
